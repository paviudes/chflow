#!/bin/bash
#SBATCH --account=def-jemerson
#SBATCH --begin=now
#SBATCH --nodes=1
#SBATCH --time=05:00:00
#SBATCH --ntasks-per-node=4
#SBATCH -o /project/def-jemerson/chbank/pavi_pavi_tp_cptp_level3_output.o
#SBATCH -e /project/def-jemerson/chbank/pavi_pavi_tp_cptp_level3_errors.o
#SBATCH --mail-type=ALL
#SBATCH --mail-user=pavithran.sridhar@gmail.com
module load intel python scipy-stack
cd /project/def-jemerson/pavi/chflow
parallel --joblog partial_decoders_pavi_tp_cptp_level3.log ./chflow.sh {1} :::: input/partial_decoders_pavi_tp_cptp_level3.txt
